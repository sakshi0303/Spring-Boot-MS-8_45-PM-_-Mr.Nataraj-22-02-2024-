package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJpaProj06CallingPlSqlpRocedureOracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJpaProj06CallingPlSqlpRocedureOracleApplication.class, args);
	}

}
