package com.nt.sbeans;

import lombok.Data;

@Data
public class Company {
   private  Integer  cid;
   private  String  name;
   private   Integer size;
}
