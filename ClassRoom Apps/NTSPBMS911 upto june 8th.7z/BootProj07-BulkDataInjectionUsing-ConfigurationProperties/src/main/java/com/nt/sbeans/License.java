package com.nt.sbeans;

import lombok.Data;

@Data
public class License {
	private  Integer lid;
	private  String type;
	private  String issuedBy;

}
