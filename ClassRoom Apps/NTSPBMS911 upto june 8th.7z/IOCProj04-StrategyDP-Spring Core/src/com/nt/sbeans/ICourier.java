//ICourier.java (Common Interface)
package com.nt.sbeans;

public interface ICourier {
   public  String deliver(int oid);
}
