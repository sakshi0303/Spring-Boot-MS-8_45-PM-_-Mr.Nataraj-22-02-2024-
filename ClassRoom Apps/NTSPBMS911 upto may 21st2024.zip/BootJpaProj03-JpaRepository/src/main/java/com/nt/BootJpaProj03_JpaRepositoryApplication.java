package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJpaProj03_JpaRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJpaProj03_JpaRepositoryApplication.class, args);
	}

}
