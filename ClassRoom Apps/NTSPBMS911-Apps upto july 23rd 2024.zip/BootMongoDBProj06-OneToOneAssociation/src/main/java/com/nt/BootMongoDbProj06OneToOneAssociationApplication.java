package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj06OneToOneAssociationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj06OneToOneAssociationApplication.class, args);
	}

}
