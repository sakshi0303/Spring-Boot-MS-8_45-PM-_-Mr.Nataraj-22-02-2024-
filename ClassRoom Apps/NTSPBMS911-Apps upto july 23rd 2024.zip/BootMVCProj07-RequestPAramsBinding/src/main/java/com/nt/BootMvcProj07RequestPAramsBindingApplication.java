package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj07RequestPAramsBindingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj07RequestPAramsBindingApplication.class, args);
	}

}
