package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMailProj01SendMailWithAattachmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
