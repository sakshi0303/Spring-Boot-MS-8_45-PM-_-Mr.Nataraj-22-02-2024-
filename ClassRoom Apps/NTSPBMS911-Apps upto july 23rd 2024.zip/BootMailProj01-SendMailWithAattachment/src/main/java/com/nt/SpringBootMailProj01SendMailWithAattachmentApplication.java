package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMailProj01SendMailWithAattachmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMailProj01SendMailWithAattachmentApplication.class, args);
	}

}
