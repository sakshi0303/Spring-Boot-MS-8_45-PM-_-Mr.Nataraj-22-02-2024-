package com.nt.service;

public interface ISeasonFinderService {
   public  String  findSeason();
}
