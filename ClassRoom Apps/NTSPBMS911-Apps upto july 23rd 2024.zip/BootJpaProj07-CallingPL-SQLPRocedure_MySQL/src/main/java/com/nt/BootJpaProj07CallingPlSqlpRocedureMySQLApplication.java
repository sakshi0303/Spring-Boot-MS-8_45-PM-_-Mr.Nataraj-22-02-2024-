package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJpaProj07CallingPlSqlpRocedureMySQLApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJpaProj07CallingPlSqlpRocedureMySQLApplication.class, args);
	}

}
