package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMongoDbProj02MongoRepository_Generators_ApplicationTests {

	@Test
	void contextLoads() {
	}

}
