package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj02MongoRepository_Generators_Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj02MongoRepository_Generators_Application.class, args);
	}

}
