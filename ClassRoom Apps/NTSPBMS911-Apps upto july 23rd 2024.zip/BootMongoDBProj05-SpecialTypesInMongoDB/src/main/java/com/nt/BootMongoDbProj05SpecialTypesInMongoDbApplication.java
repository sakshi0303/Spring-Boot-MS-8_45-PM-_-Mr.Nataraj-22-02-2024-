package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj05SpecialTypesInMongoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj05SpecialTypesInMongoDbApplication.class, args);
	}

}
