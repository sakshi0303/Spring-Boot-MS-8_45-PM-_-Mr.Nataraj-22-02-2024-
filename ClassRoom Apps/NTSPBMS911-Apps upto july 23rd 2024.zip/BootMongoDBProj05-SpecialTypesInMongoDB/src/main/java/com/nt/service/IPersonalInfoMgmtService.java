package com.nt.service;

import com.nt.document.PersonalInfo;

public interface IPersonalInfoMgmtService {
	
	public  String  registerPersonalInfo(PersonalInfo info);

}
