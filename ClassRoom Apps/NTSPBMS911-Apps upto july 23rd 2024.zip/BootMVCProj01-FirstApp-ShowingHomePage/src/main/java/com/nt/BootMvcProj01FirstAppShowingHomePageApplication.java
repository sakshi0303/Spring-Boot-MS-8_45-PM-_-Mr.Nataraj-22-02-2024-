package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj01FirstAppShowingHomePageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj01FirstAppShowingHomePageApplication.class, args);
	}

}
