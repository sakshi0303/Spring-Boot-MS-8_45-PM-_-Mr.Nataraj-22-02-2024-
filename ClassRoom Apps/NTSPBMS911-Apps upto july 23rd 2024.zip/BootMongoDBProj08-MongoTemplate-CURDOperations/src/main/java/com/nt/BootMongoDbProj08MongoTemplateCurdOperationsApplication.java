package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj08MongoTemplateCurdOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj08MongoTemplateCurdOperationsApplication.class, args);
	}

}
