package com.nt.bike;

public interface Bike {
	   public   void start();
		public  void drive();
		public  void stop();
		public void  park();
}
