package com.nt.service;

import java.util.List;

public interface ICompanyMgmtService {
	
	public   List<Object[]>  showParentToChildJoinsData();
	
	public   List<Object[]>  showChildToParentJoinsData();
	
}
