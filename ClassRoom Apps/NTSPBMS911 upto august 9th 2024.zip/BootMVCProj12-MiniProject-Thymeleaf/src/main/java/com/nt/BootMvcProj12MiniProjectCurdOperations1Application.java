package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj12MiniProjectCurdOperations1Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj12MiniProjectCurdOperations1Application.class, args);
	}

}
