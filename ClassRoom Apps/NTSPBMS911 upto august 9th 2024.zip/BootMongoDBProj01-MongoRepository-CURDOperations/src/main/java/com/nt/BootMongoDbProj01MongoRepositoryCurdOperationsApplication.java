package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj01MongoRepositoryCurdOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj01MongoRepositoryCurdOperationsApplication.class, args);
	}

}
