package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj08MiniProjectCurdOperations1Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj08MiniProjectCurdOperations1Application.class, args);
	}

}
